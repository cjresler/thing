#include <stdio.h>
#include <stdlib.h>
#include "factory.h"

struct assembler{
  int c; //number of products assembler will make
  int productsCreated;
  //char *color; // color of products
};
